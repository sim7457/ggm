<?php
include_once('../../../common.php');
$num = 2;
$title = '약도';
include_once(G5_THEME_PATH.'/head.php');
?>

<div class="sub">
    여기 약도 넣을 거임...
</div>

<?php
include_once(G5_THEME_PATH.'/tail.php');